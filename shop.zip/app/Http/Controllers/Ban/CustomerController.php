<?php

namespace App\Http\Controllers\Ban;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CustomerController extends Controller
{
    //
}
